jQuery(document).ready(function($) {
    $('.image-converter-form').on('submit', function(e) {
        e.preventDefault();

        var form = $(this);
        var formData = new FormData(form[0]);
        var inputFormat = form.data('input-format');
        var outputFormat = form.data('output-format');
        var conversionType = inputFormat + '_to_' + outputFormat;

        formData.append('action', 'handle_image_conversion');
        formData.append('conversion_type', conversionType);

        // Show loading animation
        var loadingGif = $('<img>').attr('src', 'https://pngtoavif.com/wp-content/uploads/2024/06/VAyR.gif').addClass('loading-gif');
        form.find('button[type="submit"]').hide(); // Hide the submit button
        form.append(loadingGif); // Append the loading gif

        $.ajax({
            url: icp_ajax.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                // Hide loading animation
                loadingGif.remove();
                form.find('button[type="submit"]').show(); // Show the submit button again

                if (response.success) {
                    displayConversionResults(response.data, form);
                } else {
                    alert('Conversion failed. Please try again.');
                }
            },
            error: function(xhr, status, error) {
                // Hide loading animation
                loadingGif.remove();
                form.find('button[type="submit"]').show(); // Show the submit button again

                alert('An error occurred. Please check the console for details.');
                console.error('AJAX Error:', status, error);
                console.error('Response:', xhr.responseText);
            }
        });
    });

   function displayConversionResults(data, form) {
    var resultDiv = form.siblings('.conversion-result');
    resultDiv.empty();

    var downloadAllButton = $('<button>').text('Download All').attr('id', 'download-all').addClass('button');
    var downloadAllLinks = [];

    $.each(data, function(index, file) {
        var card = $('<div>').addClass('conversion-card');
        if (file.error) {
            var errorMessage = '<p style="color: red;">Conversion failed for ' + file.originalName + '</p>';
            card.append(errorMessage);
        } else {
            var downloadLink = $('<a>').attr('href', file.outputUrl).attr('data-filename', file.outputName).text('Download');
            downloadLink.on('click', function(event) {
                event.preventDefault(); // Prevent default link behavior
                downloadFile(file.outputUrl, file.outputName);
            });
            card.append('<p>Conversion successful for ' + file.originalName + '</p>').append(downloadLink);
            downloadAllLinks.push({ url: file.outputUrl, filename: file.outputName });
        }
        resultDiv.append(card);
    });

    if (downloadAllLinks.length > 0) {
        resultDiv.prepend(downloadAllButton);
        downloadAllButton.on('click', function() {
            downloadAllFiles(downloadAllLinks);
        });
    }
}

function downloadFile(url, filename) {
    if (filename === undefined) {
        // Extract filename from the URL
        var anchor = document.createElement('a');
        anchor.href = url;
        filename = decodeURIComponent(anchor.pathname.split('/').pop());
    }
    
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}


function downloadAllFiles(files) {
    files.forEach(function(file) {
        downloadFile(file.url, file.filename);
    });
}

});
