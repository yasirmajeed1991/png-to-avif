<?php
/*
Plugin Name: Image Converter
Description: Converts PNG to AVIF and AVIF to PNG, with automatic deletion after 5 minutes.
Version: 1.2
Author: Yasir Majeed
*/

// Enqueue styles and scripts
function image_converter_styles() {
    wp_enqueue_style('image-converter-styles', plugins_url('css/style.css', __FILE__));
    wp_enqueue_script('image-converter-scripts', plugins_url('js/script.js', __FILE__), array('jquery'), null, true);
    wp_localize_script('image-converter-scripts', 'icp_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'image_converter_styles');

// Generalized Image Conversion Function
function convert_image($inputPath, $outputPath, $outputFormat) {
    if (extension_loaded('imagick')) {
        $image = new Imagick($inputPath);
        $image->setImageFormat($outputFormat);
        return $image->writeImage($outputPath);
    }
    return false;
}

// Generate conversion shortcodes dynamically
function generate_conversion_shortcodes() {
    $formats = ['png', 'avif', 'jpg', 'webp', 'bmp', 'tiff']; // Add more formats as needed

    foreach ($formats as $inputFormat) {
        foreach ($formats as $outputFormat) {
            if ($inputFormat !== $outputFormat) {
                add_shortcode("convert_{$inputFormat}_to_{$outputFormat}", function() use ($inputFormat, $outputFormat) {
                    return image_converter_shortcode($inputFormat, $outputFormat);
                });
            }
        }
    }
}

add_action('init', 'generate_conversion_shortcodes');

function image_converter_shortcode($inputFormat, $outputFormat) {
    ob_start();
    ?>
      <div class="image-converter">
        <h2 class="text-center"><?php echo strtoupper($inputFormat); ?> to <?php echo strtoupper($outputFormat); ?> Converter</h2>
        <form class="image-converter-form" method="post" enctype="multipart/form-data" data-input-format="<?php echo $inputFormat; ?>" data-output-format="<?php echo $outputFormat; ?>">
            <input type="file" name="images[]" accept=".<?php echo $inputFormat; ?>" multiple required>
            <button type="submit">Convert to <?php echo strtoupper($outputFormat); ?></button>
        </form>
        <div class="conversion-result"></div>
    </div>

    <?php
    return ob_get_clean();
}

// Handle image conversion
function handle_image_conversion() {
    if (isset($_POST['conversion_type']) && !empty($_FILES['images'])) {
        $conversionType = sanitize_text_field($_POST['conversion_type']);
        list($inputFormat, $outputFormat) = explode('_to_', $conversionType);
        $uploadDir = wp_upload_dir();
        $results = [];

        foreach ($_FILES['images']['tmp_name'] as $index => $tmp_name) {
            $uploadedFile = $_FILES['images']['tmp_name'][$index];
            $originalName = $_FILES['images']['name'][$index];
            $outputFile = $uploadDir['path'] . '/' . pathinfo($originalName, PATHINFO_FILENAME) . '.' . $outputFormat;

			$success = convert_image($uploadedFile, $outputFile, $outputFormat);

            if ($success) {
                $outputUrl = $uploadDir['url'] . '/' . basename($outputFile);
                $results[] = [
                    'originalName' => $originalName,
                    'outputUrl' => $outputUrl,
                    'outputFile' => $outputFile,
                ];
                wp_schedule_single_event(time() + 300, 'delete_temp_file', [$outputFile]);
            } else {
                $results[] = ['originalName' => $originalName, 'error' => 'Conversion failed'];
            }
        }

        wp_send_json_success($results);
    } else {
        wp_send_json_error('No images uploaded or invalid request');
    }
}

add_action('wp_ajax_handle_image_conversion', 'handle_image_conversion');
add_action('wp_ajax_nopriv_handle_image_conversion', 'handle_image_conversion');

// Temporary file deletion
function delete_temp_file($filePath) {
    if (file_exists($filePath)) {
        unlink($filePath);
    }
}

add_action('delete_temp_file', 'delete_temp_file');

// Function to check if a shortcode is used in a page/post
function is_shortcode_used($shortcode) {
    global $wpdb;
    $post_ids = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE post_type IN ('page', 'post') AND post_status = 'publish'"));
    foreach ($post_ids as $post_id) {
        $content = get_post_field('post_content', $post_id);
        if (stripos($content, $shortcode) !== false) {
            return true;
        }
    }
    return false;
}

//Admin Page for Short_codes
function image_converter_settings_page() {
    ?>
    <style>
		.widefat {
    border-collapse: collapse;
    width: 100%;
}

.widefat th,
.widefat td {
    border: 1px solid #ddd;
    padding: 8px;
}

.widefat th {
    background-color: #f2f2f2;
}

.widefat tbody tr:hover {
    background-color: #f9f9f9;
}

        .widefat tbody tr:hover {
            background-color: #f2f2f2;
        }

        .shortcode-input-container {
            display: flex;
            align-items: center;
        }

        .copy-icon {
            margin-left: 5px;
            font-size: 0; /* Hide text content */
            cursor: pointer;
            border: 1px solid #ccc;
            padding: 2px 4px;
            border-radius: 3px;
        }

        .copy-icon::after {
            content: "Copy";
            font-size: 12px; /* Adjust font size */
        }

        .pagination-container {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .pagination-button {
            margin: 0 5px;
            cursor: pointer;
            padding: 5px 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }

        .pagination-button:hover {
            background-color: #f2f2f2;
        }

        .pagination-button.active {
            background-color: #0073aa;
            color: #fff;
        }
    </style>

    <div class="wrap">
        <h1>Image Converter Shortcodes</h1>
        <p>Copy and paste the shortcodes below to use the image converter:</p>

        <!-- Search Box -->
        <input type="text" id="shortcode-search" placeholder="Search for shortcode...">

        <table class="widefat">
            <thead>
                <tr>
                    <th>Serial No.</th>
                    <th>Shortcode</th>
                    <th>Status</th> <!-- New column for indicating shortcode usage -->
					<th>Description</th>
                </tr>
            </thead>
            <tbody id="shortcode-table-body">
                <!-- Shortcode rows will be appended here dynamically -->
            </tbody>
        </table>

        <!-- Items per page dropdown -->
        <label for="items-per-page">Items per page:</label>
        <select id="items-per-page">
            <option value="5">5</option>
            <option value="10" selected>10</option>
            <option value="20">20</option>
            <option value="50">50</option>
            <option value="100">100</option>
        </select>
        <!-- Pagination -->
        <div class="pagination-container">
            <button class="pagination-button" id="prev-page">Prev</button>
            <span id="page-num"></span>
            <button class="pagination-button" id="next-page">Next</button>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.8/clipboard.min.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Clipboard Copy Functionality
            var clipboard = new ClipboardJS('.copy-icon');
            
            clipboard.on('success', function(e) {
                alert('Shortcode copied to clipboard!');
                e.clearSelection();
            });
            
            clipboard.on('error', function(e) {
                alert('Copy failed. Please try again manually.');
            });
    var shortcodes = [
                <?php
                $formats = ['png', 'avif', 'jpg', 'webp', 'bmp', 'tiff']; // Add more formats as needed
                $counter = 1;
                foreach ($formats as $inputFormat) {
                    foreach ($formats as $outputFormat) {
                        if ($inputFormat !== $outputFormat) {
                            $shortcode = "[convert_{$inputFormat}_to_{$outputFormat}]";
                            $description = strtoupper($inputFormat) . ' to ' . strtoupper($outputFormat) . ' Converter';
                             $status = is_shortcode_used($shortcode) ? '<span style="font-weight: bold; color: green;">Used</span>' : '<span style="font-weight: bold; color: red;">Not Used</span>';
                            echo "['$counter', '$shortcode','$status', '$description' ],";
                            $counter++;
                        }
                    }
                }
                ?>
            ];

    var itemsPerPage = 10; // Number of items per page
    var currentPage = 1; // Current page

   // Function to display items based on current page
	function displayItems() {
		var startIndex = (currentPage - 1) * itemsPerPage;
		var endIndex = startIndex + itemsPerPage;
		var tableBody = document.getElementById('shortcode-table-body');
		tableBody.innerHTML = '';
		for (var i = startIndex; i < endIndex && i < shortcodes.length; i++) {
			var row = '<tr>' +
				'<td>' + shortcodes[i][0] + '</td>' +
				'<td class="shortcode-cell">' +
				'<div class="shortcode-input-container">' +
				'<input type="text" value="' + shortcodes[i][1] + '" readonly="readonly" class="shortcode-input">' +
				'<button class="copy-icon" data-clipboard-text="' + shortcodes[i][1] + '"></button>' +
				'</div>' +
				'</td>' +
				'<td>' + shortcodes[i][2] + '</td>' +
				'<td>' + shortcodes[i][3] + '</td>' + // Status column
				'</tr>';
			tableBody.innerHTML += row;
		}
		updatePagination();
		applySearch(); // Apply search filter after updating items
	}

    // Function to update pagination
    function updatePagination() {
        var totalPages = Math.ceil(shortcodes.length / itemsPerPage);
        document.getElementById('page-num').textContent = currentPage + ' / ' + totalPages;
    }

// Function to apply search filter
	function applySearch() {
		var searchValue = document.getElementById('shortcode-search').value.toLowerCase();
		var shortcodes = document.querySelectorAll('.shortcode-input');
		shortcodes.forEach(function(shortcode) {
			var parentRow = shortcode.closest('tr');
			var description = parentRow.querySelector('td:nth-child(4)').textContent.toLowerCase(); // Update the column index to match the description column
			if (description.includes(searchValue)) {
				parentRow.style.display = '';
			} else {
				parentRow.style.display = 'none';
			}
		});
	}


    // Function to handle change in items per page dropdown
    document.getElementById('items-per-page').addEventListener('change', function() {
        itemsPerPage = parseInt(this.value);
        currentPage = 1; // Reset current page when changing items per page
        displayItems();
    });

    // Event listener for search box
    document.getElementById('shortcode-search').addEventListener('keyup', function() {
        currentPage = 1; // Reset current page when searching
        displayItems();
    });

    // Event listener for previous page button
    document.getElementById('prev-page').addEventListener('click', function() {
        if (currentPage > 1) {
            currentPage--;
            displayItems();
        }
    });

    // Event listener for next page button
    document.getElementById('next-page').addEventListener('click', function() {
        var totalPages = Math.ceil(shortcodes.length / itemsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            displayItems();
        }
    });

    // Initial display
    displayItems();
});


    </script>
    <?php
}


function register_image_converter_settings_page() {
    add_menu_page(
        'Image Converter Shortcodes',
        'Image Converter',
        'manage_options',
        'image-converter-settings',
        'image_converter_settings_page',
        'dashicons-format-gallery',
        30
    );
}

add_action('admin_menu', 'register_image_converter_settings_page');


//function for the front page display
function front_page_shortcode() {
    ob_start();
    ?>

    <div class="calculator-front-page">
        <h2>Search Image Converters</h2>
        <!-- Search Bar -->
        <input type="text" id="calculator-search" placeholder="Search Image Converters">

        <h2>Image Converters</h2>
        <!-- Calculator Cards -->
        <div class="calculator-cards">
            <?php
            $omit_pages = array(
                'about-us',
                'blog',
                'contact-us',
                'home',
				'privacy-policy',
				'terms-conditions',
				'disclaimer'
                
                // Add more slugs of pages you want to omit
            );

            $args = array(
                'post_type' => 'page',
                'posts_per_page' => -1, // Get all pages
                'post_status' => 'publish',
                'orderby' => 'title',
                'order' => 'ASC'
            );
            $query = new WP_Query($args);

            if ($query->have_posts()) :
                while ($query->have_posts()) : $query->the_post();
                    $slug = get_post_field('post_name', get_post());
                    if (in_array($slug, $omit_pages)) {
                        continue; // Skip omitted pages
                    }
                    ?>
                    <a href="<?php the_permalink(); ?>" class="calculator-card" >
                        <h3><?php the_title(); ?></h3>
                        <!-- Additional calculator details can go here -->
                    </a>
                <?php endwhile;
            else :
                echo 'No calculators found.';
            endif;
            wp_reset_postdata();
            ?>
        </div>
    </div>

    <style>
        .calculator-front-page {
            font-family: Arial, sans-serif;
            margin: 20px;
            text-align: center;
        }

        .calculator-front-page h2 {
            margin-top: 20px;
            font-size: 24px;
        }

        #calculator-search {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .calculator-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            grid-gap: 20px;
        }

        .calculator-card {
            background-color: #0073aa;
            border: 1px solid #ccc;
            padding: 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease; /* Added transition for background color */
            text-decoration: none;
            color: #0073aa; /* Default text color */
            display: flex;
            justify-content: center;
            align-items: center;
        }

       .calculator-card:hover {
			color: #0073aa; /* Change text color to blue on hover */
			background-color: #ffffff;
			border-color: #0073aa;
			cursor: pointer;
	    }

	  .calculator-card:hover h3 {
			color: #0073aa; /* Change text color to blue on hover */
	   }
    .calculator-card h3 {
            margin-top: 0;
            font-size: 18px;
            color: #fff;
     }
		
    </style>

	<script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.getElementById('calculator-search');
            const calculatorCards = document.querySelectorAll('.calculator-card');
            searchInput.addEventListener('input', function () {
                const searchTerm = this.value.toLowerCase().trim();

                calculatorCards.forEach(card => {
                    const title = card.querySelector('h3').textContent.toLowerCase();
                    if (title.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>

    <?php
    return ob_get_clean();
}
add_shortcode('front_page', 'front_page_shortcode');

?>
